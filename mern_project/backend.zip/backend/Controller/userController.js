const userModel = require("../Model/userModel")

exports.insertUser = async(u)=>{
    var newUser = new userModel({
        username : u.username,
        email: u.email,
        contact: u.contact,
        pwd: u.pwd,
        verify:u.verify
    })

    let i= "failure";
    await newUser.save()
    .then(()=>i="success")
    .catch(()=>i="failure")
    return i;
} 

exports.getAll = async()=>{
    let data = await userModel.find();
    return data;
}